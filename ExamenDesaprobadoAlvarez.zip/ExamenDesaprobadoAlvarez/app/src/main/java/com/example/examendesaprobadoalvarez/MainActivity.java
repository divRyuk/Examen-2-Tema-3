package com.example.examendesaprobadoalvarez;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText et1, et2, et3;
    private Switch sw1, sw2;
    private TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        et3 = findViewById(R.id.et3);
        sw1 = findViewById(R.id.sw1);
        sw2 = findViewById(R.id.sw2);
        tv1 = findViewById(R.id.tv1);
    }

    public void Grabar(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "Ventas", null, 1);
        SQLiteDatabase db = admin.getWritableDatabase();

        int patente = Integer.parseInt(et1.getText().toString());
        String cliente = et2.getText().toString();
        boolean servicio = sw1.isChecked();
        boolean importado = sw2.isChecked();
        float costo = Float.parseFloat(et3.getText().toString());

        Cursor fila = db.rawQuery("SELECT * FROM ventas WHERE patente = " + patente, null);

        if (fila.moveToFirst()) {
            Toast.makeText(this, "Ya existe un auto con esa patente", Toast.LENGTH_SHORT).show();
        } else {
            ContentValues registro = new ContentValues();
            registro.put("patente", patente);
            registro.put("cliente", cliente);
            registro.put("costo", costo);
            registro.put("servicio", servicio ? 1 : 0);
            registro.put("importado", importado ? 1 : 0);

            db.insert("ventas", null, registro);
            Toast.makeText(this, "Auto registrado correctamente", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    public void consultar(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "Ventas", null, 1);
        SQLiteDatabase db = admin.getReadableDatabase();

        int patente = Integer.parseInt(et1.getText().toString());
        Cursor fila = db.rawQuery("SELECT cliente, costo, servicio, importado FROM ventas WHERE patente = " + patente, null);

        if (fila.moveToFirst()) {
            et1.setText(fila.getString(0));
            et2.setText(fila.getString(1));
            sw1.setChecked(fila.getInt(2) == 1);
            sw2.setChecked(fila.getInt(3) == 1);
        } else {
            Toast.makeText(this, "No se encontró ese auto", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    public void informar(View v) {
        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this, "Ventas", null, 1);
        SQLiteDatabase db = admin.getReadableDatabase();

        Cursor fila = db.rawQuery("SELECT patente,cliente,service,importado,precio FROM ventas", null);
        int nacionales = 0, importados = 0, conServicio = 0;
        float total = 0;

        while (fila.moveToNext()) {
            float costo = fila.getFloat(4);
            boolean service = fila.getInt(2) == 1;
            boolean importado = fila.getInt(3) == 1;

            if (importado) {
                importados++;
                total += costo * 1.10f;
            } else {
                nacionales++;
                total += costo;
            }

            if (service) {
                conServicio++;
            }
        }

        tv1.setText("Nacionales: " + nacionales +
                "\nImportados: " + importados +
                "\nCon servicio: " + conServicio +
                "\nTotal con impuestos: $" + total);

        db.close();
    }
}
